# SwissTrovenixToken

Native token for the SwissTrovenix bridge. Solidity `^0.8.24`.

| | |
| --- | --- |
| Name | SwissTrovenix |
| Symbol | SWTX |
| Decimals | 18 |
| Max supply | 1,000,000,000 |
| Rate | 1 ETH = 2,500 SWTX |
| Fee | 0.30% of the input (`FEE_BPS = 30`) |

Both assets use 18 decimals, so `quote` works in wei.

## quote

```solidity
function quote(uint256 amountIn, bool ethToSwtx)
    public
    pure
    returns (uint256 amountOut, uint256 fee)
```

`ethToSwtx` selects the direction.

- `true`: pay ETH, receive SWTX. Output is the net input times `RATE_NUMERATOR`.
- `false`: pay SWTX, receive ETH. Output is the net input divided by `RATE_NUMERATOR`.

The fee is taken from `amountIn` before the rate is applied:

```text
fee = amountIn * 30 / 10_000
net = amountIn - fee
```

`quote` does not move tokens. It only returns `amountOut` and `fee`.

## swap

```solidity
function swap(uint256 amountIn, bool ethToSwtx) external payable returns (uint256 amountOut)
```

`swap` calls `quote`, then checks:

1. `launched` is true. Until then the call reverts with `SwissTrovenix: not launched`.
2. `amountOut` is greater than zero.
3. `totalSupply + amountOut` does not pass `MAX_SUPPLY`.

## File

`SwissTrovenixToken.sol`